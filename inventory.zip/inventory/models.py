from django.db import models

# Create your models here.
class sales(models.Model):
    date = models.DateField(max_length=50,blank=False)
    category = models.CharField(max_length=100,blank=False)
    sub_category = models.CharField(max_length=100,blank=False)
    unit_sales = models.IntegerField()
    Temperature = models.IntegerField()
    Weather = models.CharField(max_length=100,blank=False)

    def __str__(self):
        return 'category:{0} sub_category:{1}'.format(self.category,self.sub_category)

class forcast(models.Model):
    forcast_date = models.DateField(max_length=50,blank=False)
    forcast_category = models.CharField(max_length=100,blank=False)
    forcast_sub_category = models.CharField(max_length=100,blank=False)
    forcast_sales = models.IntegerField()
    

    def __str__(self):
        return 'forcast_category:{0} forcast_sub_category:{1}'.format(self.forcast_category,self.forcast_sub_category)