from cProfile import _Label, label
from turtle import title
from django.shortcuts import render
from inventory.models import sales,forcast
from wwo_hist import retrieve_hist_data
import sqlite3
import statsmodels.api as sm
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import EmailMessage, send_mail
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_text
from django.contrib.auth import authenticate, login, logout
from . tokens import generate_token
import matplotlib.pyplot as plt
from pmdarima.arima import auto_arima
from pmdarima.arima import ADFTest
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.statespace.sarimax import SARIMAX
import pandas as pd
from pandas.tseries.offsets import DateOffset
from statsmodels.tsa.seasonal import seasonal_decompose 
from statsmodels.tsa.stattools import adfuller
from pmdarima.model_selection import train_test_split

# Create your views here.
def home(request):
	title = 'Welcome: This is the Home Page'
	context = {
	"title": title,
	}
	return render(request, "home.html",context)

def list_item(request):
    title = 'List of items'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"list_item.html",context)



def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']
        
        user = authenticate(username=username, password=pass1)
        
        if user is not None:
            login(request, user)
            fname = user.first_name
            # messages.success(request, "Logged In Sucessfully!!")
            return render(request, "home.html",{"fname":fname})
        else:
            messages.error(request, "Bad Credentials!!")
            return redirect('home')
    
    return render(request, "signin.html")


def signout(request):
    logout(request)
    messages.success(request, "Logged Out Successfully!!")
    return redirect('home')


def Trend_forcasting(request):
    title = 'The Forcast information'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"Trend_forcasting.html",context)

def Graphical_Forcasting(request):
    title = 'Whole Forcast'
    queryset2 = forcast.objects.all()
    context = {
        "title":title,
        "queryset2": queryset2,
    }
    return render(request,"Graphical_Forcasting.html",context)
def index(request):
    title = 'Dashboard'
    
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"index.html",context)

def weather(request):
    #retreives 3 years historical weather data and saves in CSV
    frequency = 3
    start_date = '06-OCT-2019'
    end_date = '01-MAY-2022'
    #API KEY
    api_key = '1e9112f0a3394b3f9bc124434220506'
    location_list = ['cork', 'dublin']

    hist_weather_data = retrieve_hist_data(api_key,
                                       location_list,
                                       start_date,
                                       end_date,
                                       frequency,
                                       location_label=True,
                                       export_csv=True,
                                       store_df=False)
    return render(request,hist_weather_data)

def temp(request):
    title = 'List of items'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"temp.html",context)

def expdataanalysis(request):
    dat = sqlite3.connect('data.db')
    query = dat.execute("SELECT * From sales")
    cols = [column[0] for column in query.description]
    df= pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
    df.index
    df.info()
    #excludig the columns that has NA values
    df1 = df.dropna()
    df1.tail()
    ax = df1['Total Sales'].plot(figsize=(19,5),title=title)
    ax.autoscale(axis='x',tight=False)
    ax.set(xlabel=label, ylabel=_Label)
    #performing seasonal decomose to see the trends and seasonlity
    result = seasonal_decompose(df1['Total Sales'], model='additive')
    fig = plt.figure()  
    fig = result.plot()  
    fig.set_size_inches(12, 9)
    fig.show()
    

    def adf_test(series,title=''):
        """
        Performing ADF test to check stationarity
        """
        print(f'Augmented Dickey-Fuller Test: {title}')
        result = adfuller(series.dropna(),autolag='AIC') # .dropna() handles differenced data
    
        labels = ['ADF test statistic','p-value','# lags used','# observations']
        out = pd.Series(result[0:4],index=labels)

        for key,val in result[4].items():
            out[f'critical value ({key})']=val
        
        print(out.to_string())          # .to_string() removes the line "dtype: float64"
    
        if result[1] <= 0.05:
            print("Strong evidence against the null hypothesis")
            print("Reject the null hypothesis")
            print("Data has no unit root and is stationary")
        else:
            print("Weak evidence against the null hypothesis")
            print("Fail to reject the null hypothesis")
            print("Data has a unit root and is non-stationary")

        adf_test(df1['Total Sales'])

    #Using auto arima function of pmdarima package with exogenous variable

        SARIMAX_model = auto_arima(df1[["Total Sales"]], exogenous=df1[['Ireland Temprature']]
                          , start_p=1, start_q=1,
                         test='adf',
                         max_p=3, max_q=3,
                         m=4, #12 is the frequncy of the cycle
                         start_P=0,
                         seasonal=True, #set to seasonal
                         d=None,
                         D=1, #order of the seasonal differencing
                         trace=True,
                         error_action='ignore',
                         suppress_warnings=True,
                         stepwise=True)

    # For SARIMA Orders we set seasonal=True and pass in an m value
        model_autoarima = auto_arima(df1['Total Sales'], seasonal=True,m=4)

        model_autoarima.summary()

        model_autoarima.plot_diagnostics(figsize=(15,8))
        plt.show()

        #Splitting the dataset into training and testing  

    
        train, test = train_test_split(df1, test_size =0.3)
        print(test.shape)

        df1.dtypes

        df1.index

        #using SARIMAX function to prerdict the sales values against train dataset with seasonal order obtained from above auto arima fucntion
        model = SARIMAX(train['Total Sales'],seasonal_order=(2,1,0,4),enforce_invertibility=False)
        results = model.fit()
        results.summary()

        # Obtain predicted values
        start=len(train)
        end=len(train)+len(test)-1
        predictions = results.predict(start=start, end=end, dynamic=False).rename('Predicted')

        print(predictions)

        #using SARIMAX function to prerdict the sales values against train dataset with exogeneous variable
        model = SARIMAX(train['Total Sales'],exog=train['Ireland Temprature'],order=(0,0,1),seasonal_order=(2,1,0,4),enforce_invertibility=False, trend='n', enforce_stationarity=False)
        results = model.fit()
        results.summary()

        # Obtain predicted values
        start=len(train)
        print(start)
        end=len(train)+len(test)-1
        print(end)

        exog_forecast = test[['Ireland Temprature']]  # requires two brackets to yield a shape of (35,1)

        #saving in dataframe 
        predictions = results.predict(start=start, end=end, exog=exog_forecast).rename('Predictions')

        print(predictions)

        #forecasting the sales for the next 1 year
        future_dates = [df1.index[-1] + DateOffset(weeks=x) for x in range(0, 52)]

        print(future_dates)

        future_date_df = pd.DataFrame(index = future_dates[1:],columns = df.columns).astype(float)
        print(future_date_df.tail())


        print(future_date_df.dtypes)

        #Retraining the model with whole dataset

        model = SARIMAX(df1['Total Sales'],exog=df1['Ireland Temprature'],order=(0,0,1),seasonal_order=(2,1,0,4),enforce_invertibility=False,trend='n', enforce_stationarity=False)
        results = model.fit()


        exog_forecast=future_date_df.loc[:,['Total Sales']].fillna(0)
        print(exog_forecast)

        print(len(exog_forecast))

        future_date_df["forecast"] = results.predict(len(df1),len(df1)+50, exog=exog_forecast, dynamic= False)

        future_df = pd.concat([df1,future_date_df],ignore_index=True)
        print(future_df)

        future_df[['Total Sales', 'forecast']].plot(figsize=(12, 8))
        return render(request,SARIMAX_model)
    return render(request)


def login(request):
    title = 'Login Page'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"login.html",context)
def graph1(request):
    title = 'Dairy'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph1.html",context)
def graph2(request):
    title = 'Commercial'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph2.html",context)
def graph3(request):
    title = 'Grains'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph3.html",context)
def graph4(request):
    title = 'Meat'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph4.html",context)
def graph5(request):
    title = 'Login Page'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph5.html",context)
def graph6(request):
    title = 'Login Page'
    queryset = sales.objects.all()
    context = {
        "title":title,
        "queryset": queryset,
    }
    return render(request,"graph6.html",context)
