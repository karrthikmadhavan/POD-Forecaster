from django import forms
from .models import forcast, sales

class SalesCreateForm(forms.ModelForm):
   class Meta:
     model = sales
     fields = ['date','category', 'sub_category', 'unit_sales','Temperature','Weather']

class ForcastCreateForm(forms.ModelForm):
   class Meta:
     model = forcast
     fields = ['forcast_date','forcast_category', 'forcast_sub_category', 'forcast_sales']