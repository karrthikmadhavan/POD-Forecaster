from django.contrib import admin
from .form import SalesCreateForm,ForcastCreateForm

# Register your models here.
from .models import forcast, sales

class SalesCreateAdmin(admin.ModelAdmin):
   list_display = ['category', 'sub_category', 'unit_sales']
   form = SalesCreateForm
   list_filter = ['category']
   search_fields = ['category', 'sub_category']

class ForcastCreateAdmin(admin.ModelAdmin):
   list_display = ['forcast_category', 'forcast_sub_category', 'forcast_sales']
   form = ForcastCreateForm
   list_filter = ['forcast_category']
   search_fields = ['forcast_category', 'forcast_sub_category']

admin.site.register(sales,SalesCreateAdmin)
admin.site.register(forcast,ForcastCreateAdmin)